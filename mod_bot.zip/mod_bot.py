import os
import discord
import json
from discord.ext import commands
from discord.ext.commands import has_permissions
from dotenv import load_dotenv

# Load token
load_dotenv()
TOKEN = os.getenv("DISCORD_TOKEN")

# Bot setup
intents = discord.Intents.default()
intents.message_content = True
intents.members = True
bot = commands.Bot(command_prefix="!", intents=intents)

# Log channel ID (replace with your actual log channel ID)
LOG_CHANNEL_ID = 123456789012345678

# Load or initialize warnings
if not os.path.exists("warnings.json"):
    with open("warnings.json", "w") as f:
        json.dump({}, f)

def load_warnings():
    with open("warnings.json", "r") as f:
        return json.load(f)

def save_warnings(warnings):
    with open("warnings.json", "w") as f:
        json.dump(warnings, f, indent=4)

async def log_action(guild, message):
    log_channel = guild.get_channel(LOG_CHANNEL_ID)
    if log_channel:
        await log_channel.send(message)

@bot.event
async def on_ready():
    print(f"Logged in as {bot.user}")

# Kick
@bot.command()
@has_permissions(kick_members=True)
async def kick(ctx, member: discord.Member, *, reason=None):
    await member.kick(reason=reason)
    await ctx.send(f"{member} has been kicked.")
    await log_action(ctx.guild, f"🔨 {member} was kicked by {ctx.author}. Reason: {reason}")

# Ban
@bot.command()
@has_permissions(ban_members=True)
async def ban(ctx, member: discord.Member, *, reason=None):
    await member.ban(reason=reason)
    await ctx.send(f"{member} has been banned.")
    await log_action(ctx.guild, f"⛔ {member} was banned by {ctx.author}. Reason: {reason}")

# Clear
@bot.command()
@has_permissions(manage_messages=True)
async def clear(ctx, amount: int = 5):
    await ctx.channel.purge(limit=amount + 1)
    await ctx.send(f"🧹 Cleared {amount} messages!", delete_after=3)
    await log_action(ctx.guild, f"🧹 {ctx.author} cleared {amount} messages in {ctx.channel.name}.")

# Mute (timeout)
@bot.command()
@has_permissions(moderate_members=True)
async def mute(ctx, member: discord.Member, duration: int, *, reason=None):
    try:
        await member.timeout(discord.utils.utcnow() + discord.timedelta(minutes=duration), reason=reason)
        await ctx.send(f"{member.mention} has been muted for {duration} minutes.")
        await log_action(ctx.guild, f"🤐 {member} was muted by {ctx.author} for {duration}m. Reason: {reason}")
    except Exception as e:
        await ctx.send("❌ Failed to mute user.")
        print(e)

# Warn + Auto Punish
@bot.command()
@has_permissions(manage_messages=True)
async def warn(ctx, member: discord.Member, *, reason=None):
    warnings = load_warnings()
    user_id = str(member.id)
    if user_id not in warnings:
        warnings[user_id] = []
    warnings[user_id].append({"reason": reason, "mod": str(ctx.author)})
    save_warnings(warnings)

    warn_count = len(warnings[user_id])
    await ctx.send(f"{member.mention} has been warned. Total warnings: {warn_count}. Reason: {reason}")
    await log_action(ctx.guild, f"⚠️ {member} was warned by {ctx.author}. Reason: {reason}. Total warnings: {warn_count}")

    # Auto punishments
    try:
        if warn_count == 3:
            await member.timeout(discord.utils.utcnow() + discord.timedelta(minutes=30), reason="3 warnings")
            await ctx.send(f"🔇 {member.mention} has been muted for 30 minutes (3 warnings).")
            await log_action(ctx.guild, f"🔇 {member} auto-muted for 30 minutes (3 warnings).")
        elif warn_count == 5:
            await member.kick(reason="5 warnings")
            await ctx.send(f"👢 {member.mention} has been kicked (5 warnings).")
            await log_action(ctx.guild, f"👢 {member} auto-kicked (5 warnings).")
        elif warn_count == 7:
            await member.ban(reason="7 warnings")
            await ctx.send(f"🚫 {member.mention} has been banned (7 warnings).")
            await log_action(ctx.guild, f"🚫 {member} auto-banned (7 warnings).")
    except Exception as e:
        await ctx.send("⚠️ Tried to punish but something went wrong.")
        print(e)

# Check Warnings
@bot.command()
@has_permissions(manage_messages=True)
async def warnings(ctx, member: discord.Member):
    warnings = load_warnings()
    user_id = str(member.id)
    if user_id in warnings and warnings[user_id]:
        embed = discord.Embed(title=f"Warnings for {member}", color=discord.Color.orange())
        for i, entry in enumerate(warnings[user_id], 1):
            embed.add_field(name=f"#{i}", value=f"Reason: {entry['reason']}
Mod: {entry['mod']}", inline=False)
        await ctx.send(embed=embed)
    else:
        await ctx.send(f"{member.mention} has no warnings.")

# Errors
@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.MissingPermissions):
        await ctx.send("🚫 You don't have permission to do that.")
    elif isinstance(error, commands.MissingRequiredArgument):
        await ctx.send("❗ Missing argument.")
    elif isinstance(error, commands.BadArgument):
        await ctx.send("⚠️ Invalid argument.")
    else:
        print(error)
        await ctx.send("❌ An unexpected error occurred.")

# Run
bot.run(TOKEN)
